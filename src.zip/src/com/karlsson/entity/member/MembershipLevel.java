package com.karlsson.entity.member;

    public enum MembershipLevel {
        STANDARD,
        STUDENT,
        PREMIUM
    }
