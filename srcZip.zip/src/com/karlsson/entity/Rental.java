package com.karlsson.entity;

import com.karlsson.entity.item.Item;
import com.karlsson.entity.member.Member;
import java.time.LocalDate;

public class Rental {
    private Member member;
    private Item item;
    private LocalDate rentedOn;
    private LocalDate returnBy;
    private boolean activeRental;
    private double price;

    public Rental(Member member, Item item, LocalDate returnBy, double price) {
        this.member = member;
        this.item = item;
        this.rentedOn = LocalDate.now(); // vi antar att uthyrningen ska börja samma dag som beställningen sker
        this.returnBy = returnBy;
        this.activeRental = true;
        this.price = price;
    }

    public Member getMember() {return member;}

    public void setMember(Member member) {this.member = member;}

    public Item getItem() {return item;}

    public void setItem(Item item) {this.item = item;}

    public LocalDate getRentedOn() {return rentedOn;}

    public void setRentedOn(LocalDate rentedOn) {this.rentedOn = rentedOn;}

    public LocalDate getReturnBy() {return returnBy;}

    public void setReturnBy(LocalDate returnBy) {this.returnBy = returnBy;}

    public boolean isActiveRental() {return activeRental;}

    public void setActiveRental(boolean activeRental) {this.activeRental = activeRental;}

    public double getPrice() {return price;}

    public void setPrice(double price) {this.price = price;}
}
